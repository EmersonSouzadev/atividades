const dia = document.querySelector('#dia');
const mes = document.querySelector('#mes');
const ano= document.querySelector('#ano');
const semana = document.querySelector('#semana');

//evento
const data = setInterval(calendario,);
function calendario() {

    let data = new Date();
    let dias = data.getDate();
    let meses = data.getMonth() + 1;
    let anos = data.getFullYear();
    let dias2 = data.getDay() ;
   
    if (dias < 10){
        dias = '0'+ dias
    }; 
    if (meses < 10){
       meses = "0" + meses
    } ; 
  if (dias2 == 1){
    dias2 = 'Hoje é Segunda-Feira!'
  }
  if (dias2 == 2){
    dias2 = 'Hoje é Terça-Feira!'
  }
  if (dias2 == 3){
    dias2 = 'Hoje é Quarta-Feira!'
  }
  if (dias2 == 4){
    dias2 = 'Hoje é Quinta-Feira!'
  }
  if (dias2 == 5){
    dias2 = 'Hoje é Sexta-Feira!'
  }
  if (dias2 == 6){
    dias2 = 'Hoje é Sábado!'
  }
  if (dias2 == 7){
    dias2 = 'Hoje é Domingo!'
  }
    
    semana.textContent= dias2;
    dia.textContent= dias;
    mes.textContent= meses;
    ano.textContent= anos;
   

}



