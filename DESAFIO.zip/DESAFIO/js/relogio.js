//DOM
const hora = document.querySelector('#hora');
const minuto = document.querySelector('#minuto');
const segundo = document.querySelector('#segundo');
const titulo = document.querySelector('#titulo')

//evento
const relogio = setInterval(tempo, 1000);
function tempo() {

    let dia = new Date()
    let hr = dia.getHours();
    let min = dia.getMinutes();
    let seg = dia.getSeconds();
    
    if (hr < 10) {
        hr = '0' + hr
    };
    if (min < 10) {
        min = "0" + min
    };
    if (seg < 10) {
        seg = "0" + seg
    };
    if(hr < 12 ){
        titulo.innerHTML = 'Bom Dia!'
    }
    if(hr >=12 && hr <= 18){
        titulo.innerText = 'Boa Tarde!'
    }
    if(hr >= 19 && hr <= 00){
        titulo.inner = 'Boa Noite!'
    }




    hora.textContent = hr;
    minuto.textContent = min;
    segundo.textContent = seg;
}







